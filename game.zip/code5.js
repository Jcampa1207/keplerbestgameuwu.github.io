gdjs.nivel_32BonusCode = {};
gdjs.nivel_32BonusCode.localVariables = [];
gdjs.nivel_32BonusCode.GDNewVideoObjects1= [];
gdjs.nivel_32BonusCode.GDNewVideoObjects2= [];
gdjs.nivel_32BonusCode.GDNewTextObjects1= [];
gdjs.nivel_32BonusCode.GDNewTextObjects2= [];
gdjs.nivel_32BonusCode.GDEarthLikePlanetObjects1= [];
gdjs.nivel_32BonusCode.GDEarthLikePlanetObjects2= [];
gdjs.nivel_32BonusCode.GDBlackSpaceObjects1= [];
gdjs.nivel_32BonusCode.GDBlackSpaceObjects2= [];
gdjs.nivel_32BonusCode.GDStarryBackgroundRotaryStar1Objects1= [];
gdjs.nivel_32BonusCode.GDStarryBackgroundRotaryStar1Objects2= [];


gdjs.nivel_32BonusCode.mapOfGDgdjs_9546nivel_959532BonusCode_9546GDNewTextObjects1Objects = Hashtable.newFrom({"NewText": gdjs.nivel_32BonusCode.GDNewTextObjects1});
gdjs.nivel_32BonusCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.nivel_32BonusCode.GDNewTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.nivel_32BonusCode.mapOfGDgdjs_9546nivel_959532BonusCode_9546GDNewTextObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene3", false);
}}

}


};

gdjs.nivel_32BonusCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.nivel_32BonusCode.GDNewVideoObjects1.length = 0;
gdjs.nivel_32BonusCode.GDNewVideoObjects2.length = 0;
gdjs.nivel_32BonusCode.GDNewTextObjects1.length = 0;
gdjs.nivel_32BonusCode.GDNewTextObjects2.length = 0;
gdjs.nivel_32BonusCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.nivel_32BonusCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.nivel_32BonusCode.GDBlackSpaceObjects1.length = 0;
gdjs.nivel_32BonusCode.GDBlackSpaceObjects2.length = 0;
gdjs.nivel_32BonusCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.nivel_32BonusCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;

gdjs.nivel_32BonusCode.eventsList0(runtimeScene);
gdjs.nivel_32BonusCode.GDNewVideoObjects1.length = 0;
gdjs.nivel_32BonusCode.GDNewVideoObjects2.length = 0;
gdjs.nivel_32BonusCode.GDNewTextObjects1.length = 0;
gdjs.nivel_32BonusCode.GDNewTextObjects2.length = 0;
gdjs.nivel_32BonusCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.nivel_32BonusCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.nivel_32BonusCode.GDBlackSpaceObjects1.length = 0;
gdjs.nivel_32BonusCode.GDBlackSpaceObjects2.length = 0;
gdjs.nivel_32BonusCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.nivel_32BonusCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;


return;

}

gdjs['nivel_32BonusCode'] = gdjs.nivel_32BonusCode;
