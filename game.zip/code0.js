gdjs.PlaySceneCode = {};
gdjs.PlaySceneCode.localVariables = [];
gdjs.PlaySceneCode.GDFireButtonObjects2_1final = [];

gdjs.PlaySceneCode.GDLeftButtonObjects3_1final = [];

gdjs.PlaySceneCode.GDRightButtonObjects2_1final = [];

gdjs.PlaySceneCode.GDTopButtonObjects2_1final = [];

gdjs.PlaySceneCode.GDTopButtonObjects3_1final = [];

gdjs.PlaySceneCode.forEachIndex3 = 0;

gdjs.PlaySceneCode.forEachIndex4 = 0;

gdjs.PlaySceneCode.forEachObjects3 = [];

gdjs.PlaySceneCode.forEachObjects4 = [];

gdjs.PlaySceneCode.forEachTemporary3 = null;

gdjs.PlaySceneCode.forEachTemporary4 = null;

gdjs.PlaySceneCode.forEachTotalCount3 = 0;

gdjs.PlaySceneCode.forEachTotalCount4 = 0;

gdjs.PlaySceneCode.GDPlayerObjects1= [];
gdjs.PlaySceneCode.GDPlayerObjects2= [];
gdjs.PlaySceneCode.GDPlayerObjects3= [];
gdjs.PlaySceneCode.GDPlayerObjects4= [];
gdjs.PlaySceneCode.GDPlayerObjects5= [];
gdjs.PlaySceneCode.GDPlayerObjects6= [];
gdjs.PlaySceneCode.GDBulletObjects1= [];
gdjs.PlaySceneCode.GDBulletObjects2= [];
gdjs.PlaySceneCode.GDBulletObjects3= [];
gdjs.PlaySceneCode.GDBulletObjects4= [];
gdjs.PlaySceneCode.GDBulletObjects5= [];
gdjs.PlaySceneCode.GDBulletObjects6= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects1= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects2= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects3= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects4= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects5= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects6= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects1= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects2= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects3= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects4= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects5= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects6= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects1= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects2= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects3= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects4= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects5= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects6= [];
gdjs.PlaySceneCode.GDLifeBarObjects1= [];
gdjs.PlaySceneCode.GDLifeBarObjects2= [];
gdjs.PlaySceneCode.GDLifeBarObjects3= [];
gdjs.PlaySceneCode.GDLifeBarObjects4= [];
gdjs.PlaySceneCode.GDLifeBarObjects5= [];
gdjs.PlaySceneCode.GDLifeBarObjects6= [];
gdjs.PlaySceneCode.GDGameOverObjects1= [];
gdjs.PlaySceneCode.GDGameOverObjects2= [];
gdjs.PlaySceneCode.GDGameOverObjects3= [];
gdjs.PlaySceneCode.GDGameOverObjects4= [];
gdjs.PlaySceneCode.GDGameOverObjects5= [];
gdjs.PlaySceneCode.GDGameOverObjects6= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects1= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects2= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects3= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects4= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects5= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects6= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects1= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects2= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects4= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects5= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects6= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects1= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects2= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects3= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects4= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects5= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects6= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects1= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects2= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects3= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects4= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects5= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects6= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects1= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects2= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects3= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects4= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects5= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects6= [];
gdjs.PlaySceneCode.GDBulletHitObjects1= [];
gdjs.PlaySceneCode.GDBulletHitObjects2= [];
gdjs.PlaySceneCode.GDBulletHitObjects3= [];
gdjs.PlaySceneCode.GDBulletHitObjects4= [];
gdjs.PlaySceneCode.GDBulletHitObjects5= [];
gdjs.PlaySceneCode.GDBulletHitObjects6= [];
gdjs.PlaySceneCode.GDBulletFlashObjects1= [];
gdjs.PlaySceneCode.GDBulletFlashObjects2= [];
gdjs.PlaySceneCode.GDBulletFlashObjects3= [];
gdjs.PlaySceneCode.GDBulletFlashObjects4= [];
gdjs.PlaySceneCode.GDBulletFlashObjects5= [];
gdjs.PlaySceneCode.GDBulletFlashObjects6= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects1= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects2= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects3= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects4= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects5= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects6= [];
gdjs.PlaySceneCode.GDMotionTrailObjects1= [];
gdjs.PlaySceneCode.GDMotionTrailObjects2= [];
gdjs.PlaySceneCode.GDMotionTrailObjects3= [];
gdjs.PlaySceneCode.GDMotionTrailObjects4= [];
gdjs.PlaySceneCode.GDMotionTrailObjects5= [];
gdjs.PlaySceneCode.GDMotionTrailObjects6= [];
gdjs.PlaySceneCode.GDTutorialTextObjects1= [];
gdjs.PlaySceneCode.GDTutorialTextObjects2= [];
gdjs.PlaySceneCode.GDTutorialTextObjects3= [];
gdjs.PlaySceneCode.GDTutorialTextObjects4= [];
gdjs.PlaySceneCode.GDTutorialTextObjects5= [];
gdjs.PlaySceneCode.GDTutorialTextObjects6= [];
gdjs.PlaySceneCode.GDContinueTextObjects1= [];
gdjs.PlaySceneCode.GDContinueTextObjects2= [];
gdjs.PlaySceneCode.GDContinueTextObjects3= [];
gdjs.PlaySceneCode.GDContinueTextObjects4= [];
gdjs.PlaySceneCode.GDContinueTextObjects5= [];
gdjs.PlaySceneCode.GDContinueTextObjects6= [];
gdjs.PlaySceneCode.GDRightButtonObjects1= [];
gdjs.PlaySceneCode.GDRightButtonObjects2= [];
gdjs.PlaySceneCode.GDRightButtonObjects3= [];
gdjs.PlaySceneCode.GDRightButtonObjects4= [];
gdjs.PlaySceneCode.GDRightButtonObjects5= [];
gdjs.PlaySceneCode.GDRightButtonObjects6= [];
gdjs.PlaySceneCode.GDLeftButtonObjects1= [];
gdjs.PlaySceneCode.GDLeftButtonObjects2= [];
gdjs.PlaySceneCode.GDLeftButtonObjects3= [];
gdjs.PlaySceneCode.GDLeftButtonObjects4= [];
gdjs.PlaySceneCode.GDLeftButtonObjects5= [];
gdjs.PlaySceneCode.GDLeftButtonObjects6= [];
gdjs.PlaySceneCode.GDTopButtonObjects1= [];
gdjs.PlaySceneCode.GDTopButtonObjects2= [];
gdjs.PlaySceneCode.GDTopButtonObjects3= [];
gdjs.PlaySceneCode.GDTopButtonObjects4= [];
gdjs.PlaySceneCode.GDTopButtonObjects5= [];
gdjs.PlaySceneCode.GDTopButtonObjects6= [];
gdjs.PlaySceneCode.GDFireButtonObjects1= [];
gdjs.PlaySceneCode.GDFireButtonObjects2= [];
gdjs.PlaySceneCode.GDFireButtonObjects3= [];
gdjs.PlaySceneCode.GDFireButtonObjects4= [];
gdjs.PlaySceneCode.GDFireButtonObjects5= [];
gdjs.PlaySceneCode.GDFireButtonObjects6= [];
gdjs.PlaySceneCode.GDScoreObjects1= [];
gdjs.PlaySceneCode.GDScoreObjects2= [];
gdjs.PlaySceneCode.GDScoreObjects3= [];
gdjs.PlaySceneCode.GDScoreObjects4= [];
gdjs.PlaySceneCode.GDScoreObjects5= [];
gdjs.PlaySceneCode.GDScoreObjects6= [];
gdjs.PlaySceneCode.GDBlueSpaceship3Objects1= [];
gdjs.PlaySceneCode.GDBlueSpaceship3Objects2= [];
gdjs.PlaySceneCode.GDBlueSpaceship3Objects3= [];
gdjs.PlaySceneCode.GDBlueSpaceship3Objects4= [];
gdjs.PlaySceneCode.GDBlueSpaceship3Objects5= [];
gdjs.PlaySceneCode.GDBlueSpaceship3Objects6= [];
gdjs.PlaySceneCode.GDSunObjects1= [];
gdjs.PlaySceneCode.GDSunObjects2= [];
gdjs.PlaySceneCode.GDSunObjects3= [];
gdjs.PlaySceneCode.GDSunObjects4= [];
gdjs.PlaySceneCode.GDSunObjects5= [];
gdjs.PlaySceneCode.GDSunObjects6= [];
gdjs.PlaySceneCode.GDEarthLikePlanetObjects1= [];
gdjs.PlaySceneCode.GDEarthLikePlanetObjects2= [];
gdjs.PlaySceneCode.GDEarthLikePlanetObjects3= [];
gdjs.PlaySceneCode.GDEarthLikePlanetObjects4= [];
gdjs.PlaySceneCode.GDEarthLikePlanetObjects5= [];
gdjs.PlaySceneCode.GDEarthLikePlanetObjects6= [];
gdjs.PlaySceneCode.GDBlackSpaceObjects1= [];
gdjs.PlaySceneCode.GDBlackSpaceObjects2= [];
gdjs.PlaySceneCode.GDBlackSpaceObjects3= [];
gdjs.PlaySceneCode.GDBlackSpaceObjects4= [];
gdjs.PlaySceneCode.GDBlackSpaceObjects5= [];
gdjs.PlaySceneCode.GDBlackSpaceObjects6= [];
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects1= [];
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects2= [];
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects3= [];
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects4= [];
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects5= [];
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects6= [];


gdjs.PlaySceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlaySceneCode.GDTutorialTextObjects2);
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "MultiTouchControls", 0, 0, 0);
}{for(var i = 0, len = gdjs.PlaySceneCode.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDTutorialTextObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlaySceneCode.GDMediumAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlaySceneCode.GDSmallAsteroidObjects1);
{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.random(3));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.random(1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.random(1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].setAngle(gdjs.random(360));
}
for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].setAngle(gdjs.random(360));
}
for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].setPosition(gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].setPosition(gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].setPosition(gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
}}

}


};gdjs.PlaySceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("GamePlaying");
}
{ //Subevents
gdjs.PlaySceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMotionTrailObjects3Objects = Hashtable.newFrom({"MotionTrail": gdjs.PlaySceneCode.GDMotionTrailObjects3});
gdjs.PlaySceneCode.mapOfEmptyGDTopButtonObjects = Hashtable.newFrom({"TopButton": []});
gdjs.PlaySceneCode.eventsList2 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.PlaySceneCode.GDMotionTrailObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMotionTrailObjects3Objects, 0, 0, "");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlaySceneCode.GDMotionTrailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDMotionTrailObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMotionTrailObjects3[i].setPosition((( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointX("MotionTrail")),(( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointY("MotionTrail")));
}
}}

}


{

gdjs.PlaySceneCode.GDTopButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDTopButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlaySceneCode.GDTopButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDTopButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDTopButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDTopButtonObjects4[k] = gdjs.PlaySceneCode.GDTopButtonObjects4[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDTopButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDTopButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDTopButtonObjects3_1final.indexOf(gdjs.PlaySceneCode.GDTopButtonObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDTopButtonObjects3_1final.push(gdjs.PlaySceneCode.GDTopButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDTopButtonObjects3_1final, gdjs.PlaySceneCode.GDTopButtonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14215748);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlaySceneCode.GDMotionTrailObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDMotionTrailObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMotionTrailObjects3[i].startEmission();
}
}}

}


{

gdjs.PlaySceneCode.GDTopButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "w"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDTopButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlaySceneCode.GDTopButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDTopButtonObjects3.length;i<l;++i) {
    if ( !(gdjs.PlaySceneCode.GDTopButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDTopButtonObjects3[k] = gdjs.PlaySceneCode.GDTopButtonObjects3[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDTopButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDTopButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDTopButtonObjects2_1final.indexOf(gdjs.PlaySceneCode.GDTopButtonObjects3[j]) === -1 )
            gdjs.PlaySceneCode.GDTopButtonObjects2_1final.push(gdjs.PlaySceneCode.GDTopButtonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfEmptyGDTopButtonObjects) == 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDTopButtonObjects2_1final, gdjs.PlaySceneCode.GDTopButtonObjects2);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlaySceneCode.GDMotionTrailObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDMotionTrailObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMotionTrailObjects2[i].stopEmission();
}
}}

}


};gdjs.PlaySceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.PlaySceneCode.GDTopButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDTopButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlaySceneCode.GDTopButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDTopButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDTopButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDTopButtonObjects4[k] = gdjs.PlaySceneCode.GDTopButtonObjects4[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDTopButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDTopButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDTopButtonObjects3_1final.indexOf(gdjs.PlaySceneCode.GDTopButtonObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDTopButtonObjects3_1final.push(gdjs.PlaySceneCode.GDTopButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDTopButtonObjects3_1final, gdjs.PlaySceneCode.GDTopButtonObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects3[i].getBehavior("Physics2").applyPolarForce((gdjs.PlaySceneCode.GDPlayerObjects3[i].getAngle()), 4.5, (gdjs.PlaySceneCode.GDPlayerObjects3[i].getPointX("")), (gdjs.PlaySceneCode.GDPlayerObjects3[i].getPointY("")));
}
}}

}


{

gdjs.PlaySceneCode.GDLeftButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDLeftButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs.PlaySceneCode.GDLeftButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDLeftButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDLeftButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDLeftButtonObjects4[k] = gdjs.PlaySceneCode.GDLeftButtonObjects4[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDLeftButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDLeftButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDLeftButtonObjects3_1final.indexOf(gdjs.PlaySceneCode.GDLeftButtonObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDLeftButtonObjects3_1final.push(gdjs.PlaySceneCode.GDLeftButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDLeftButtonObjects3_1final, gdjs.PlaySceneCode.GDLeftButtonObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects3[i].getBehavior("Physics2").applyTorque(-(0.5));
}
}}

}


{

gdjs.PlaySceneCode.GDRightButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDRightButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs.PlaySceneCode.GDRightButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDRightButtonObjects3.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDRightButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDRightButtonObjects3[k] = gdjs.PlaySceneCode.GDRightButtonObjects3[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDRightButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDRightButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDRightButtonObjects2_1final.indexOf(gdjs.PlaySceneCode.GDRightButtonObjects3[j]) === -1 )
            gdjs.PlaySceneCode.GDRightButtonObjects2_1final.push(gdjs.PlaySceneCode.GDRightButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDRightButtonObjects2_1final, gdjs.PlaySceneCode.GDRightButtonObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("Physics2").applyTorque(0.5);
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects2});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletFlashObjects2Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlaySceneCode.GDBulletFlashObjects2});
gdjs.PlaySceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects2);
gdjs.PlaySceneCode.GDFireButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("FireBullet").IsReadyToShoot((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlaySceneCode.GDPlayerObjects2[k] = gdjs.PlaySceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDFireButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("FireButton"), gdjs.PlaySceneCode.GDFireButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDFireButtonObjects3.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDFireButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDFireButtonObjects3[k] = gdjs.PlaySceneCode.GDFireButtonObjects3[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDFireButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDFireButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDFireButtonObjects2_1final.indexOf(gdjs.PlaySceneCode.GDFireButtonObjects3[j]) === -1 )
            gdjs.PlaySceneCode.GDFireButtonObjects2_1final.push(gdjs.PlaySceneCode.GDFireButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDFireButtonObjects2_1final, gdjs.PlaySceneCode.GDFireButtonObjects2);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PlaySceneCode.GDPlayerObjects2 */
gdjs.PlaySceneCode.GDBulletObjects2.length = 0;

gdjs.PlaySceneCode.GDBulletFlashObjects2.length = 0;

{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.PlaySceneCode.GDPlayerObjects2[i].getPointX("BulletSpawn")), (gdjs.PlaySceneCode.GDPlayerObjects2[i].getPointY("BulletSpawn")), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects2Objects, (gdjs.PlaySceneCode.GDPlayerObjects2[i].getAngle()), 175, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects2[i].setZOrder((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "LaserFire.wav", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletFlashObjects2Objects, (( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getPointX("BulletFlash")), (( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletFlashObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletFlashObjects2[i].setAngle((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletFlashObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletFlashObjects2[i].setZOrder((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects4Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects4Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlaySceneCode.GDBigAsteroidObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisHugeObjects4Objects = Hashtable.newFrom({"DebrisHuge": gdjs.PlaySceneCode.GDDebrisHugeObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects4Objects = Hashtable.newFrom({"BulletHit": gdjs.PlaySceneCode.GDBulletHitObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects5});
gdjs.PlaySceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBigAsteroidObjects4, gdjs.PlaySceneCode.GDBigAsteroidObjects5);

gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4, gdjs.PlaySceneCode.GDBulletObjects5);

gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects, (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].putAroundObject((gdjs.PlaySceneCode.GDBigAsteroidObjects5.length !== 0 ? gdjs.PlaySceneCode.GDBigAsteroidObjects5[0] : null), 15, (( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) - 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(-(60), 0), 5, (gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBigAsteroidObjects4, gdjs.PlaySceneCode.GDBigAsteroidObjects5);

gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4, gdjs.PlaySceneCode.GDBulletObjects5);

gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects, (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].putAroundObject((gdjs.PlaySceneCode.GDBigAsteroidObjects5.length !== 0 ? gdjs.PlaySceneCode.GDBigAsteroidObjects5[0] : null), 15, (( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(0, 60), 5, (gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects4Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects4Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisMediumObjects4Objects = Hashtable.newFrom({"DebrisMedium": gdjs.PlaySceneCode.GDDebrisMediumObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects4Objects = Hashtable.newFrom({"BulletHit": gdjs.PlaySceneCode.GDBulletHitObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects5Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects5Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects5});
gdjs.PlaySceneCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects5);
gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4, gdjs.PlaySceneCode.GDBulletObjects5);

gdjs.copyArray(gdjs.PlaySceneCode.GDMediumAsteroidObjects4, gdjs.PlaySceneCode.GDMediumAsteroidObjects5);

gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects5Objects, (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].putAroundObject((gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length !== 0 ? gdjs.PlaySceneCode.GDMediumAsteroidObjects5[0] : null), 8, (( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) - 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(-(60), 0), 2, (gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4, gdjs.PlaySceneCode.GDBulletObjects5);

gdjs.copyArray(gdjs.PlaySceneCode.GDMediumAsteroidObjects4, gdjs.PlaySceneCode.GDMediumAsteroidObjects5);

gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects5Objects, (( gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDMediumAsteroidObjects5[0].getPointX("")), (( gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDMediumAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].putAroundObject((gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length !== 0 ? gdjs.PlaySceneCode.GDMediumAsteroidObjects5[0] : null), 8, (( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(0, 60), 2, (gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects3Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisSmallObjects3Objects = Hashtable.newFrom({"DebrisSmall": gdjs.PlaySceneCode.GDDebrisSmallObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlaySceneCode.GDBulletHitObjects3});
gdjs.PlaySceneCode.eventsList7 = function(runtimeScene) {

};gdjs.PlaySceneCode.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects3);

for (gdjs.PlaySceneCode.forEachIndex4 = 0;gdjs.PlaySceneCode.forEachIndex4 < gdjs.PlaySceneCode.GDBigAsteroidObjects3.length;++gdjs.PlaySceneCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects4);
gdjs.PlaySceneCode.GDBulletHitObjects4.length = 0;

gdjs.PlaySceneCode.GDDebrisHugeObjects4.length = 0;

gdjs.PlaySceneCode.GDBigAsteroidObjects4.length = 0;


gdjs.PlaySceneCode.forEachTemporary4 = gdjs.PlaySceneCode.GDBigAsteroidObjects3[gdjs.PlaySceneCode.forEachIndex4];
gdjs.PlaySceneCode.GDBigAsteroidObjects4.push(gdjs.PlaySceneCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects4Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisHugeObjects4Objects, (( gdjs.PlaySceneCode.GDBigAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects4[0].getPointX("")), (( gdjs.PlaySceneCode.GDBigAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects4Objects, (( gdjs.PlaySceneCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects4[0].getPointX("BulletHit")), (( gdjs.PlaySceneCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects4[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.PlaySceneCode.eventsList5(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlaySceneCode.GDMediumAsteroidObjects3);

for (gdjs.PlaySceneCode.forEachIndex4 = 0;gdjs.PlaySceneCode.forEachIndex4 < gdjs.PlaySceneCode.GDMediumAsteroidObjects3.length;++gdjs.PlaySceneCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects4);
gdjs.PlaySceneCode.GDBulletHitObjects4.length = 0;

gdjs.PlaySceneCode.GDDebrisMediumObjects4.length = 0;

gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length = 0;


gdjs.PlaySceneCode.forEachTemporary4 = gdjs.PlaySceneCode.GDMediumAsteroidObjects3[gdjs.PlaySceneCode.forEachIndex4];
gdjs.PlaySceneCode.GDMediumAsteroidObjects4.push(gdjs.PlaySceneCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects4Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 55, gdjs.randomFloatInRange(1, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisMediumObjects4Objects, (( gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDMediumAsteroidObjects4[0].getPointX("")), (( gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDMediumAsteroidObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects4Objects, (( gdjs.PlaySceneCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects4[0].getPointX("BulletHit")), (( gdjs.PlaySceneCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects4[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.PlaySceneCode.eventsList6(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlaySceneCode.GDSmallAsteroidObjects2);

for (gdjs.PlaySceneCode.forEachIndex3 = 0;gdjs.PlaySceneCode.forEachIndex3 < gdjs.PlaySceneCode.GDSmallAsteroidObjects2.length;++gdjs.PlaySceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects3);
gdjs.PlaySceneCode.GDBulletHitObjects3.length = 0;

gdjs.PlaySceneCode.GDDebrisSmallObjects3.length = 0;

gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length = 0;


gdjs.PlaySceneCode.forEachTemporary3 = gdjs.PlaySceneCode.GDSmallAsteroidObjects2[gdjs.PlaySceneCode.forEachIndex3];
gdjs.PlaySceneCode.GDSmallAsteroidObjects3.push(gdjs.PlaySceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects3Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 50, gdjs.randomFloatInRange(1.1, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisSmallObjects3Objects, (( gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDSmallAsteroidObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDSmallAsteroidObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects3Objects, (( gdjs.PlaySceneCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlaySceneCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PlaySceneCode.GDPlayerObjects2});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects2ObjectsGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects2ObjectsGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects2Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlaySceneCode.GDBigAsteroidObjects2, "MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects2, "SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects2});
gdjs.PlaySceneCode.asyncCallback14172572 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PlaySceneCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene", false);
}gdjs.PlaySceneCode.localVariables.length = 0;
}
gdjs.PlaySceneCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.PlaySceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlaySceneCode.asyncCallback14172572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlaySceneCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__CameraShake__SetLayerTranslationAmplitude.func(runtimeScene, 1, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerRotationAmplitude.func(runtimeScene, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerZoomAmplitude.func(runtimeScene, 1.01, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetDefaultShakingFrequency.func(runtimeScene, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects2);
gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlaySceneCode.GDMediumAsteroidObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlaySceneCode.GDSmallAsteroidObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDPlayerObjects2Objects, "Physics2", gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects2ObjectsGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects2ObjectsGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects2Objects, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlaySceneCode.GDLifeBarObjects2);
/* Reuse gdjs.PlaySceneCode.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Bump.wav", false, 60, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDLifeBarObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDLifeBarObjects2[i].SetValue((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlaySceneCode.GDPlayerObjects1[k] = gdjs.PlaySceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlaySceneCode.GDMotionTrailObjects1);
{for(var i = 0, len = gdjs.PlaySceneCode.GDMotionTrailObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMotionTrailObjects1[i].stopEmission();
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setString("GameOverAnimation");
}
{ //Subevents
gdjs.PlaySceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.eventsList11 = function(runtimeScene) {

{


gdjs.PlaySceneCode.eventsList2(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList3(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.PlaySceneCode.eventsList4(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList8(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList10(runtimeScene);
}


};gdjs.PlaySceneCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) == "GamePlaying";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlaySceneCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathShipParticleObjects3Objects = Hashtable.newFrom({"DeathShipParticle": gdjs.PlaySceneCode.GDDeathShipParticleObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3});
gdjs.PlaySceneCode.asyncCallback14178100 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PlaySceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("ContinueText"), gdjs.PlaySceneCode.GDContinueTextObjects3);

{for(var i = 0, len = gdjs.PlaySceneCode.GDContinueTextObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDContinueTextObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setString("GameOverWaitKey");
}gdjs.PlaySceneCode.localVariables.length = 0;
}
gdjs.PlaySceneCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.PlaySceneCode.localVariables);
for (const obj of gdjs.PlaySceneCode.GDContinueTextObjects2) asyncObjectsList.addObject("ContinueText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlaySceneCode.asyncCallback14178100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlaySceneCode.eventsList14 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14174092);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlaySceneCode.GDDeathShipParticleObjects3.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathShipParticleObjects3Objects, (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDDeathShipParticleObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDDeathShipParticleObjects3[i].setAngle((( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14176476);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "GameOver", 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14177396);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueText"), gdjs.PlaySceneCode.GDContinueTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlaySceneCode.GDTutorialTextObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDTutorialTextObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDContinueTextObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDContinueTextObjects2[i].hide();
}
}
{ //Subevents
gdjs.PlaySceneCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) == "GameOverAnimation";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlaySceneCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) == "GameOverWaitKey";
if (isConditionTrue_0) {
}

}


};gdjs.PlaySceneCode.eventsList16 = function(runtimeScene) {

};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects1});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSunObjects1Objects = Hashtable.newFrom({"Sun": gdjs.PlaySceneCode.GDSunObjects1});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects1Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlaySceneCode.GDBigAsteroidObjects1});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSunObjects1Objects = Hashtable.newFrom({"Sun": gdjs.PlaySceneCode.GDSunObjects1});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects1Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects1});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSunObjects1Objects = Hashtable.newFrom({"Sun": gdjs.PlaySceneCode.GDSunObjects1});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects1Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects1});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSunObjects1Objects = Hashtable.newFrom({"Sun": gdjs.PlaySceneCode.GDSunObjects1});
gdjs.PlaySceneCode.eventsList17 = function(runtimeScene) {

{



}


{


gdjs.PlaySceneCode.eventsList1(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList12(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList15(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "GameTimer");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.PlaySceneCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.PlaySceneCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDScoreObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "GameTimer"))));
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.PlaySceneCode.GDScoreObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDScoreObjects1.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDScoreObjects1[i].getBehavior("Text").getText() == "20" ) {
        isConditionTrue_0 = true;
        gdjs.PlaySceneCode.GDScoreObjects1[k] = gdjs.PlaySceneCode.GDScoreObjects1[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDScoreObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "explicacion", false);
}}

}


{


gdjs.PlaySceneCode.eventsList16(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sun"), gdjs.PlaySceneCode.GDSunObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects1Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSunObjects1Objects, 10, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sun"), gdjs.PlaySceneCode.GDSunObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects1Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSunObjects1Objects, 10, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlaySceneCode.GDSmallAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sun"), gdjs.PlaySceneCode.GDSunObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects1Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSunObjects1Objects, 10, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlaySceneCode.GDMediumAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sun"), gdjs.PlaySceneCode.GDSunObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects1Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSunObjects1Objects, 10, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene", false);
}}

}


};

gdjs.PlaySceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PlaySceneCode.GDPlayerObjects1.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects2.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects3.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects4.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects5.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletObjects6.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects1.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects2.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects3.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects4.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects5.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects6.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects1.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects2.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects3.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects4.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects5.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects6.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects1.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects2.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects3.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects4.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects5.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects6.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects1.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects2.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects4.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects5.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects6.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects1.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects2.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects3.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects4.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects5.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects6.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects1.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects2.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects3.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects4.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects5.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects6.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects1.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects2.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects3.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects4.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects5.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects6.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects1.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects2.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects3.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects4.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects5.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects6.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDScoreObjects1.length = 0;
gdjs.PlaySceneCode.GDScoreObjects2.length = 0;
gdjs.PlaySceneCode.GDScoreObjects3.length = 0;
gdjs.PlaySceneCode.GDScoreObjects4.length = 0;
gdjs.PlaySceneCode.GDScoreObjects5.length = 0;
gdjs.PlaySceneCode.GDScoreObjects6.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects1.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects2.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects3.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects4.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects5.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects6.length = 0;
gdjs.PlaySceneCode.GDSunObjects1.length = 0;
gdjs.PlaySceneCode.GDSunObjects2.length = 0;
gdjs.PlaySceneCode.GDSunObjects3.length = 0;
gdjs.PlaySceneCode.GDSunObjects4.length = 0;
gdjs.PlaySceneCode.GDSunObjects5.length = 0;
gdjs.PlaySceneCode.GDSunObjects6.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects3.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects4.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects5.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects6.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects1.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects2.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects3.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects4.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects5.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects6.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects3.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects4.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects5.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects6.length = 0;

gdjs.PlaySceneCode.eventsList17(runtimeScene);
gdjs.PlaySceneCode.GDPlayerObjects1.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects2.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects3.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects4.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects5.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletObjects6.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects1.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects2.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects3.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects4.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects5.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects6.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects1.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects2.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects3.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects4.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects5.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects6.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects1.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects2.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects3.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects4.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects5.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects6.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects1.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects2.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects4.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects5.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects6.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects1.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects2.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects3.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects4.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects5.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects6.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects1.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects2.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects3.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects4.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects5.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects6.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects1.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects2.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects3.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects4.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects5.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects6.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects1.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects2.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects3.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects4.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects5.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects6.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDScoreObjects1.length = 0;
gdjs.PlaySceneCode.GDScoreObjects2.length = 0;
gdjs.PlaySceneCode.GDScoreObjects3.length = 0;
gdjs.PlaySceneCode.GDScoreObjects4.length = 0;
gdjs.PlaySceneCode.GDScoreObjects5.length = 0;
gdjs.PlaySceneCode.GDScoreObjects6.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects1.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects2.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects3.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects4.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects5.length = 0;
gdjs.PlaySceneCode.GDBlueSpaceship3Objects6.length = 0;
gdjs.PlaySceneCode.GDSunObjects1.length = 0;
gdjs.PlaySceneCode.GDSunObjects2.length = 0;
gdjs.PlaySceneCode.GDSunObjects3.length = 0;
gdjs.PlaySceneCode.GDSunObjects4.length = 0;
gdjs.PlaySceneCode.GDSunObjects5.length = 0;
gdjs.PlaySceneCode.GDSunObjects6.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects3.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects4.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects5.length = 0;
gdjs.PlaySceneCode.GDEarthLikePlanetObjects6.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects1.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects2.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects3.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects4.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects5.length = 0;
gdjs.PlaySceneCode.GDBlackSpaceObjects6.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects3.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects4.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects5.length = 0;
gdjs.PlaySceneCode.GDStarryBackgroundRotaryStar1Objects6.length = 0;


return;

}

gdjs['PlaySceneCode'] = gdjs.PlaySceneCode;
