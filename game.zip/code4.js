gdjs.explicacionCode = {};
gdjs.explicacionCode.localVariables = [];
gdjs.explicacionCode.GDfelicidadesObjects1= [];
gdjs.explicacionCode.GDfelicidadesObjects2= [];
gdjs.explicacionCode.GDAsteroidObjects1= [];
gdjs.explicacionCode.GDAsteroidObjects2= [];
gdjs.explicacionCode.GDpresionaObjects1= [];
gdjs.explicacionCode.GDpresionaObjects2= [];
gdjs.explicacionCode.GDEarthLikePlanetObjects1= [];
gdjs.explicacionCode.GDEarthLikePlanetObjects2= [];
gdjs.explicacionCode.GDBlackSpaceObjects1= [];
gdjs.explicacionCode.GDBlackSpaceObjects2= [];
gdjs.explicacionCode.GDStarryBackgroundRotaryStar1Objects1= [];
gdjs.explicacionCode.GDStarryBackgroundRotaryStar1Objects2= [];


gdjs.explicacionCode.mapOfGDgdjs_9546explicacionCode_9546GDAsteroidObjects1Objects = Hashtable.newFrom({"Asteroid": gdjs.explicacionCode.GDAsteroidObjects1});
gdjs.explicacionCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Asteroid"), gdjs.explicacionCode.GDAsteroidObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.explicacionCode.mapOfGDgdjs_9546explicacionCode_9546GDAsteroidObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "explicacion 2 . 1", false);
}}

}


};

gdjs.explicacionCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.explicacionCode.GDfelicidadesObjects1.length = 0;
gdjs.explicacionCode.GDfelicidadesObjects2.length = 0;
gdjs.explicacionCode.GDAsteroidObjects1.length = 0;
gdjs.explicacionCode.GDAsteroidObjects2.length = 0;
gdjs.explicacionCode.GDpresionaObjects1.length = 0;
gdjs.explicacionCode.GDpresionaObjects2.length = 0;
gdjs.explicacionCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacionCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacionCode.GDBlackSpaceObjects1.length = 0;
gdjs.explicacionCode.GDBlackSpaceObjects2.length = 0;
gdjs.explicacionCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.explicacionCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;

gdjs.explicacionCode.eventsList0(runtimeScene);
gdjs.explicacionCode.GDfelicidadesObjects1.length = 0;
gdjs.explicacionCode.GDfelicidadesObjects2.length = 0;
gdjs.explicacionCode.GDAsteroidObjects1.length = 0;
gdjs.explicacionCode.GDAsteroidObjects2.length = 0;
gdjs.explicacionCode.GDpresionaObjects1.length = 0;
gdjs.explicacionCode.GDpresionaObjects2.length = 0;
gdjs.explicacionCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacionCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacionCode.GDBlackSpaceObjects1.length = 0;
gdjs.explicacionCode.GDBlackSpaceObjects2.length = 0;
gdjs.explicacionCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.explicacionCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;


return;

}

gdjs['explicacionCode'] = gdjs.explicacionCode;
