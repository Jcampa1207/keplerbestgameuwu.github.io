gdjs.explicacion_323er_32leyCode = {};
gdjs.explicacion_323er_32leyCode.localVariables = [];
gdjs.explicacion_323er_32leyCode.GDNewVideoObjects1= [];
gdjs.explicacion_323er_32leyCode.GDNewVideoObjects2= [];
gdjs.explicacion_323er_32leyCode.GDSunObjects1= [];
gdjs.explicacion_323er_32leyCode.GDSunObjects2= [];
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects1= [];
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects2= [];
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects1= [];
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects2= [];
gdjs.explicacion_323er_32leyCode.GDBlackSpaceObjects1= [];
gdjs.explicacion_323er_32leyCode.GDBlackSpaceObjects2= [];
gdjs.explicacion_323er_32leyCode.GDStarryBackgroundRotaryStar1Objects1= [];
gdjs.explicacion_323er_32leyCode.GDStarryBackgroundRotaryStar1Objects2= [];


gdjs.explicacion_323er_32leyCode.mapOfGDgdjs_9546explicacion_9595323er_959532leyCode_9546GDSunObjects1Objects = Hashtable.newFrom({"Sun": gdjs.explicacion_323er_32leyCode.GDSunObjects1});
gdjs.explicacion_323er_32leyCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Sun"), gdjs.explicacion_323er_32leyCode.GDSunObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.explicacion_323er_32leyCode.mapOfGDgdjs_9546explicacion_9595323er_959532leyCode_9546GDSunObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gracias por jugar", false);
}}

}


};

gdjs.explicacion_323er_32leyCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.explicacion_323er_32leyCode.GDNewVideoObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDNewVideoObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDSunObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDSunObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDBlackSpaceObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDBlackSpaceObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;

gdjs.explicacion_323er_32leyCode.eventsList0(runtimeScene);
gdjs.explicacion_323er_32leyCode.GDNewVideoObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDNewVideoObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDSunObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDSunObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDBlackSpaceObjects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDBlackSpaceObjects2.length = 0;
gdjs.explicacion_323er_32leyCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.explicacion_323er_32leyCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;


return;

}

gdjs['explicacion_323er_32leyCode'] = gdjs.explicacion_323er_32leyCode;
