gdjs.gracias_32por_32jugarCode = {};
gdjs.gracias_32por_32jugarCode.localVariables = [];
gdjs.gracias_32por_32jugarCode.GDNewVideoObjects1= [];
gdjs.gracias_32por_32jugarCode.GDNewVideoObjects2= [];
gdjs.gracias_32por_32jugarCode.GDNewTextObjects1= [];
gdjs.gracias_32por_32jugarCode.GDNewTextObjects2= [];
gdjs.gracias_32por_32jugarCode.GDEarthLikePlanetObjects1= [];
gdjs.gracias_32por_32jugarCode.GDEarthLikePlanetObjects2= [];
gdjs.gracias_32por_32jugarCode.GDBlackSpaceObjects1= [];
gdjs.gracias_32por_32jugarCode.GDBlackSpaceObjects2= [];
gdjs.gracias_32por_32jugarCode.GDStarryBackgroundRotaryStar1Objects1= [];
gdjs.gracias_32por_32jugarCode.GDStarryBackgroundRotaryStar1Objects2= [];


gdjs.gracias_32por_32jugarCode.mapOfGDgdjs_9546gracias_959532por_959532jugarCode_9546GDNewTextObjects1Objects = Hashtable.newFrom({"NewText": gdjs.gracias_32por_32jugarCode.GDNewTextObjects1});
gdjs.gracias_32por_32jugarCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.gracias_32por_32jugarCode.GDNewTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.gracias_32por_32jugarCode.mapOfGDgdjs_9546gracias_959532por_959532jugarCode_9546GDNewTextObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene", false);
}}

}


};

gdjs.gracias_32por_32jugarCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.gracias_32por_32jugarCode.GDNewVideoObjects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDNewVideoObjects2.length = 0;
gdjs.gracias_32por_32jugarCode.GDNewTextObjects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDNewTextObjects2.length = 0;
gdjs.gracias_32por_32jugarCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.gracias_32por_32jugarCode.GDBlackSpaceObjects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDBlackSpaceObjects2.length = 0;
gdjs.gracias_32por_32jugarCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;

gdjs.gracias_32por_32jugarCode.eventsList0(runtimeScene);
gdjs.gracias_32por_32jugarCode.GDNewVideoObjects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDNewVideoObjects2.length = 0;
gdjs.gracias_32por_32jugarCode.GDNewTextObjects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDNewTextObjects2.length = 0;
gdjs.gracias_32por_32jugarCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.gracias_32por_32jugarCode.GDBlackSpaceObjects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDBlackSpaceObjects2.length = 0;
gdjs.gracias_32por_32jugarCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.gracias_32por_32jugarCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;


return;

}

gdjs['gracias_32por_32jugarCode'] = gdjs.gracias_32por_32jugarCode;
