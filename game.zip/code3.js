gdjs.explicacion_322_32_46_321Code = {};
gdjs.explicacion_322_32_46_321Code.localVariables = [];
gdjs.explicacion_322_32_46_321Code.GDley_95951Objects1= [];
gdjs.explicacion_322_32_46_321Code.GDley_95951Objects2= [];
gdjs.explicacion_322_32_46_321Code.GDEmoteCircleObjects1= [];
gdjs.explicacion_322_32_46_321Code.GDEmoteCircleObjects2= [];
gdjs.explicacion_322_32_46_321Code.GDNewVideoObjects1= [];
gdjs.explicacion_322_32_46_321Code.GDNewVideoObjects2= [];
gdjs.explicacion_322_32_46_321Code.GDSunObjects1= [];
gdjs.explicacion_322_32_46_321Code.GDSunObjects2= [];
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects1= [];
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects2= [];
gdjs.explicacion_322_32_46_321Code.GDley_95952Objects1= [];
gdjs.explicacion_322_32_46_321Code.GDley_95952Objects2= [];
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects1= [];
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects2= [];
gdjs.explicacion_322_32_46_321Code.GDBlackSpaceObjects1= [];
gdjs.explicacion_322_32_46_321Code.GDBlackSpaceObjects2= [];
gdjs.explicacion_322_32_46_321Code.GDStarryBackgroundRotaryStar1Objects1= [];
gdjs.explicacion_322_32_46_321Code.GDStarryBackgroundRotaryStar1Objects2= [];


gdjs.explicacion_322_32_46_321Code.mapOfGDgdjs_9546explicacion_9595322_959532_959546_9595321Code_9546GDEarthLikePlanetObjects1Objects = Hashtable.newFrom({"EarthLikePlanet": gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects1});
gdjs.explicacion_322_32_46_321Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("EarthLikePlanet"), gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.explicacion_322_32_46_321Code.mapOfGDgdjs_9546explicacion_9595322_959532_959546_9595321Code_9546GDEarthLikePlanetObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene2", false);
}}

}


};

gdjs.explicacion_322_32_46_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.explicacion_322_32_46_321Code.GDley_95951Objects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDley_95951Objects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEmoteCircleObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEmoteCircleObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDNewVideoObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDNewVideoObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDSunObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDSunObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDley_95952Objects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDley_95952Objects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDBlackSpaceObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDBlackSpaceObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDStarryBackgroundRotaryStar1Objects2.length = 0;

gdjs.explicacion_322_32_46_321Code.eventsList0(runtimeScene);
gdjs.explicacion_322_32_46_321Code.GDley_95951Objects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDley_95951Objects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEmoteCircleObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEmoteCircleObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDNewVideoObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDNewVideoObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDSunObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDSunObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDley_95952Objects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDley_95952Objects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDBlackSpaceObjects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDBlackSpaceObjects2.length = 0;
gdjs.explicacion_322_32_46_321Code.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.explicacion_322_32_46_321Code.GDStarryBackgroundRotaryStar1Objects2.length = 0;


return;

}

gdjs['explicacion_322_32_46_321Code'] = gdjs.explicacion_322_32_46_321Code;
