gdjs.explicacion_322_32leyCode = {};
gdjs.explicacion_322_32leyCode.localVariables = [];
gdjs.explicacion_322_32leyCode.GDNewVideoObjects1= [];
gdjs.explicacion_322_32leyCode.GDNewVideoObjects2= [];
gdjs.explicacion_322_32leyCode.GDNewTextObjects1= [];
gdjs.explicacion_322_32leyCode.GDNewTextObjects2= [];
gdjs.explicacion_322_32leyCode.GDEarthLikePlanetObjects1= [];
gdjs.explicacion_322_32leyCode.GDEarthLikePlanetObjects2= [];
gdjs.explicacion_322_32leyCode.GDBlackSpaceObjects1= [];
gdjs.explicacion_322_32leyCode.GDBlackSpaceObjects2= [];
gdjs.explicacion_322_32leyCode.GDStarryBackgroundRotaryStar1Objects1= [];
gdjs.explicacion_322_32leyCode.GDStarryBackgroundRotaryStar1Objects2= [];


gdjs.explicacion_322_32leyCode.mapOfGDgdjs_9546explicacion_9595322_959532leyCode_9546GDNewTextObjects1Objects = Hashtable.newFrom({"NewText": gdjs.explicacion_322_32leyCode.GDNewTextObjects1});
gdjs.explicacion_322_32leyCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.explicacion_322_32leyCode.GDNewTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.explicacion_322_32leyCode.mapOfGDgdjs_9546explicacion_9595322_959532leyCode_9546GDNewTextObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "nivel Bonus", false);
}}

}


};

gdjs.explicacion_322_32leyCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.explicacion_322_32leyCode.GDNewVideoObjects1.length = 0;
gdjs.explicacion_322_32leyCode.GDNewVideoObjects2.length = 0;
gdjs.explicacion_322_32leyCode.GDNewTextObjects1.length = 0;
gdjs.explicacion_322_32leyCode.GDNewTextObjects2.length = 0;
gdjs.explicacion_322_32leyCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_322_32leyCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_322_32leyCode.GDBlackSpaceObjects1.length = 0;
gdjs.explicacion_322_32leyCode.GDBlackSpaceObjects2.length = 0;
gdjs.explicacion_322_32leyCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.explicacion_322_32leyCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;

gdjs.explicacion_322_32leyCode.eventsList0(runtimeScene);
gdjs.explicacion_322_32leyCode.GDNewVideoObjects1.length = 0;
gdjs.explicacion_322_32leyCode.GDNewVideoObjects2.length = 0;
gdjs.explicacion_322_32leyCode.GDNewTextObjects1.length = 0;
gdjs.explicacion_322_32leyCode.GDNewTextObjects2.length = 0;
gdjs.explicacion_322_32leyCode.GDEarthLikePlanetObjects1.length = 0;
gdjs.explicacion_322_32leyCode.GDEarthLikePlanetObjects2.length = 0;
gdjs.explicacion_322_32leyCode.GDBlackSpaceObjects1.length = 0;
gdjs.explicacion_322_32leyCode.GDBlackSpaceObjects2.length = 0;
gdjs.explicacion_322_32leyCode.GDStarryBackgroundRotaryStar1Objects1.length = 0;
gdjs.explicacion_322_32leyCode.GDStarryBackgroundRotaryStar1Objects2.length = 0;


return;

}

gdjs['explicacion_322_32leyCode'] = gdjs.explicacion_322_32leyCode;
